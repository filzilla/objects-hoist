## Scope, hoisting and compartmentalization

### Answer the following:
In you own words, explain the concepts of scope, hoisting, compartmentalization.


### Provide examples for all three, below:

#### Scope:

#### Hoisting:

#### Compartmentalization:
